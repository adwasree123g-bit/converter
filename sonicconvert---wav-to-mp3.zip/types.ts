
export type ConversionStatus = 'idle' | 'converting' | 'completed' | 'error';

export interface FileData {
  file: File;
  name: string;
  size: string;
  id: string;
}
