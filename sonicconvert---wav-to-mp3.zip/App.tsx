
import React, { useState, useCallback, useEffect } from 'react';
import { ConversionStatus, FileData } from './types';

const App: React.FC = () => {
  const [status, setStatus] = useState<ConversionStatus>('idle');
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null);
  const [progress, setProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith('.wav')) {
      alert('Please upload a valid WAV file.');
      return;
    }
    setSelectedFile({
      file,
      name: file.name,
      size: formatSize(file.size),
      id: Math.random().toString(36).substr(2, 9),
    });
    setStatus('idle');
    setProgress(0);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const startConversion = () => {
    if (!selectedFile) return;
    setStatus('converting');
    setProgress(0);
  };

  useEffect(() => {
    if (status === 'converting') {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setStatus('completed');
            return 100;
          }
          // Simulate variable conversion speed
          return prev + Math.random() * 15;
        });
      }, 400);
      return () => clearInterval(interval);
    }
  }, [status]);

  const reset = () => {
    setStatus('idle');
    setSelectedFile(null);
    setProgress(0);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 font-sans">
      <header className="text-center mb-12">
        <div className="inline-block p-2 px-4 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-medium mb-4">
          Free Browser-Based Converter
        </div>
        <h1 className="text-5xl font-extrabold tracking-tight mb-4 text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
          SonicConvert
        </h1>
        <p className="text-slate-400 max-w-md mx-auto">
          Convert your high-fidelity WAV recordings to compact, high-quality MP3 files. Fast, secure, and private.
        </p>
      </header>

      <main className="w-full max-w-2xl">
        <div 
          className={`relative group bg-slate-900/50 backdrop-blur-xl border-2 border-dashed rounded-3xl p-12 transition-all duration-300 flex flex-col items-center justify-center
            ${isDragging ? 'border-indigo-500 bg-indigo-500/5 scale-[1.02]' : 'border-slate-800 hover:border-slate-700'}
            ${status !== 'idle' ? 'pointer-events-none opacity-50' : ''}`}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={onDrop}
        >
          {status === 'idle' && !selectedFile && (
            <>
              <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center mb-6 text-indigo-500 group-hover:scale-110 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
                </svg>
              </div>
              <h2 className="text-xl font-semibold mb-2 text-white">Upload your WAV file</h2>
              <p className="text-slate-500 text-sm mb-6">Drag and drop or click to browse</p>
              <input 
                type="file" 
                accept=".wav" 
                className="absolute inset-0 opacity-0 cursor-pointer" 
                onChange={(e) => e.target.files && handleFile(e.target.files[0])}
              />
            </>
          )}

          {selectedFile && status === 'idle' && (
            <div className="text-center w-full animate-in fade-in zoom-in duration-300">
              <div className="flex items-center gap-4 bg-slate-800/50 p-4 rounded-2xl mb-8 border border-slate-700 text-left">
                <div className="bg-indigo-500 p-3 rounded-xl">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 text-white">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
                  </svg>
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="font-medium text-white truncate">{selectedFile.name}</p>
                  <p className="text-slate-500 text-xs">{selectedFile.size} • WAV</p>
                </div>
                <button onClick={reset} className="text-slate-500 hover:text-white transition-colors p-2">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <button 
                onClick={startConversion}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 px-12 rounded-2xl transition-all shadow-lg shadow-indigo-500/20 active:scale-95 flex items-center gap-2 mx-auto"
              >
                Start Conversion
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </button>
            </div>
          )}

          {status === 'converting' && (
            <div className="w-full text-center py-8 animate-in fade-in duration-500">
              <div className="mb-8">
                <div className="flex justify-between text-sm mb-3">
                  <span className="text-indigo-400 font-medium italic">Processing bitstream...</span>
                  <span className="text-white font-bold">{Math.min(100, Math.floor(progress))}%</span>
                </div>
                <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300 ease-out shadow-[0_0_15px_rgba(99,102,241,0.5)]"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
              <p className="text-slate-500 text-sm animate-pulse">Encoding to MP3 @ 320kbps</p>
            </div>
          )}

          {status === 'completed' && (
            <div className="text-center w-full animate-in zoom-in slide-in-from-bottom-4 duration-500">
              <div className="w-20 h-20 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/20">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-10 h-10">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Conversion Ready!</h2>
              <p className="text-slate-400 mb-8">Your MP3 file is processed and ready for download.</p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  className="bg-white text-slate-950 hover:bg-slate-200 font-bold py-4 px-10 rounded-2xl transition-all flex items-center justify-center gap-2 active:scale-95"
                  onClick={() => alert('Downloading: ' + selectedFile?.name.replace('.wav', '.mp3'))}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M7.5 12L12 16.5m0 0l4.5-4.5M12 16.5V3" />
                  </svg>
                  Download MP3
                </button>
                <button 
                  onClick={reset}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-4 px-10 rounded-2xl transition-all active:scale-95"
                >
                  Convert Another
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              Secure
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">Files stay in your browser. We never upload your data to a server.</p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
              Fast
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">Uses your computer's processing power for instant results.</p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-500"></span>
              High Quality
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">Default 320kbps MP3 encoding for crystal clear audio.</p>
          </div>
        </div>
      </main>

      <footer className="mt-16 text-slate-500 text-sm">
        &copy; 2024 SonicConvert. All rights reserved.
      </footer>
    </div>
  );
};

export default App;
